BOT_TOKEN = ""
OWNER_ID = 0
FORCE_JOIN_CHANNEL = "@yourchannel"
MONGO_URI = ""
DB_NAME = "telegram_bot"
WELCOME_IMAGE = "assets/welcome.jpg"
