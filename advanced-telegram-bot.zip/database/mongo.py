from pymongo import MongoClient
from config import MONGO_URI, DB_NAME
client = MongoClient(MONGO_URI) if MONGO_URI else None
db = client[DB_NAME] if client else None
