from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from config import BOT_TOKEN, FORCE_JOIN_CHANNEL

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Join Channel", url=f"https://t.me/{FORCE_JOIN_CHANNEL.replace('@','')}")],
        [InlineKeyboardButton("✅ Verify", callback_data="verify")]
    ])
    await update.message.reply_text("🔒 Access Locked. Join channel first.", reply_markup=kb)

async def verify(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text("⏳ Processing... Checking membership...")
    try:
        m = await context.bot.get_chat_member(FORCE_JOIN_CHANNEL, q.from_user.id)
        if m.status in ["member","administrator","creator"]:
            await q.edit_message_text("✅ Verified! Access granted.")
        else:
            raise Exception()
    except:
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📢 Join Channel", url=f"https://t.me/{FORCE_JOIN_CHANNEL.replace('@','')}")],
            [InlineKeyboardButton("🔄 Verify Again", callback_data="verify")]
        ])
        await q.edit_message_text("❌ Join the channel first.", reply_markup=kb)

app = Application.builder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(verify, pattern="verify"))

if __name__ == "__main__":
    app.run_polling()
